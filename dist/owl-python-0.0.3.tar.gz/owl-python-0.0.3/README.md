![owl](https://github.com/lazylearn-ai/owl-python/assets/158150401/3d1986ba-e9a1-4e6e-8a23-12cc692c7353)
owl-python is lightweight ml library for image analysis. it helps us explore our computer vision datasets easily. owl insludes powerful plotting tools based on plotly, seaborn and matplotlib.
## Install

To install the current release run:

```
$ pip install owl-python
```

## License

[MIT License](LICENSE)
